package project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class RemoveCharacter {

	public static void main(String[] args) throws FileNotFoundException {
		//	Scanner console = new Scanner(System.in);
		Scanner inputFile = new Scanner(new File("input.txt"));
		String str = inputFile.nextLine();
		inputFile.close();

		PrintWriter outFile = new PrintWriter("outputFile.txt");


		StringTokenizer output = new StringTokenizer(str," ");
		List<String> elements = new ArrayList<String>();
		
	
		while (output.hasMoreTokens())
			outFile.println(output.nextToken().trim());
		outFile.flush();
		outFile.close();

	}

}